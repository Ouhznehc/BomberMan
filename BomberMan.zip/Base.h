#ifndef _BASE_
#define _BASE_
#include <bits/stdc++.h>
#include <windows.h>
#include <cwchar>
#include <conio.h>
using namespace std;
int robot_time = 0;
//w a s d ����
int dx[4] = {-1, 0, 1, 0};
int dy[4] = {0, -1, 0, 1};
#endif
